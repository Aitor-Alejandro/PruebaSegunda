package com.curso.inicio.controllerTest;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.curso.model.Empleado;
import com.curso.service.EmpleadoService;

@SpringBootTest
@AutoConfigureMockMvc
class EmpleadoControllerTest {
    @MockitoBean						//@MockBean en 3.3.X
    private EmpleadoService service;
   @Autowired
    private MockMvc mockMvc;

    
    @BeforeEach
    public void setup() {
        Empleado empleado = new Empleado(1,"Pepito", "Gil", "pepito@lsq.com");
        when(service.getEmpleadoById(1)).thenReturn(empleado);
        when(service.getAllEmpleados()).thenReturn(Arrays.asList(empleado));
    }
    
    @Test
    public void testGetListTodosLosEmpleados() throws Exception {
        mockMvc.perform(get("/api/empleados"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre", is("Pepito")))
                .andExpect(jsonPath("$[0].apellido", is("Gil")));
    }
    @Test
    public void testCrearEmpleado() throws Exception {
        Empleado empleado = new Empleado("Ana", "Sira","ana@lqs.com");
      //  doNothing().when(service).crearEmpleado(any(Empleado.class));

        mockMvc.perform(post("/api/empleados")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"nombre\":\"Ana\",\"apellido\":\"Sira\",\"email\":\"ana@lqs.com\"}"))
                .andExpect(status().is2xxSuccessful());  //isok()
    }
    
    @Test
    public void testEliminarEmpleado() throws Exception {
        doNothing().when(service).eliminarEmpleado(1);
        mockMvc.perform(delete("/api/empleados/1"))
                .andExpect(status().is2xxSuccessful());     //isok()
    }
}
