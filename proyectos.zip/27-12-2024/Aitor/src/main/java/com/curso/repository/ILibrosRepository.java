package com.curso.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curso.model.Libro;
@Repository
public interface ILibrosRepository extends JpaRepository<Libro, Integer> {//JpaRepository <Entidad, WrapperClavePrimaria>
//TODO Ejercicio
//usando @Query------>Buscar por titulo
//usando keyword----->Buscar por tematica
}
//ESTA INTERFAZ QUEDA VACIA
