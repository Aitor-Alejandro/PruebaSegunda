package com.curso.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 2024-12-27
 */
@Entity
@Table(name="libros")
public class Libro {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)//Esto hace que el RestContrller, en el metodo POST, no sea necesario inicializar el isbn 
	int isbn;
	@Column(name="titulo_de_un_libro")
	String tituloDeUnLibro;//En base de datos titulo_de_un_libro
	String tematica;
	
	public Libro() {
		super();
	}
	
	public Libro(int isbn) {
		super();
		this.isbn = isbn;
	}
	
	public Libro(int isbn, String titulo, String tematica) {
		super();
		this.isbn = isbn;
		this.tituloDeUnLibro = titulo;
		this.tematica = tematica;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getTitulo() {
		return tituloDeUnLibro;
	}

	public void setTitulo(String titulo) {
		this.tituloDeUnLibro = titulo;
	}

	public String getTematica() {
		return tematica;
	}

	public void setTematica(String tematica) {
		this.tematica = tematica;
	}
	
	
}
