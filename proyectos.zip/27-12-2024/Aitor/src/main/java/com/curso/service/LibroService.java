package com.curso.service;
import java.util.List;

import com.curso.model.Libro;
import com.curso.repository.ILibrosRepository;


public interface LibroService extends ILibrosRepository {
	List<Libro> libros();
	Libro buscarLibro(int isbn);
	void altaLibro(Libro libro);
	void actualizar(Libro libro);
	List<Libro> eliminarLibro(int isbn);
	//TODO metodos de la interfaz repository
}
