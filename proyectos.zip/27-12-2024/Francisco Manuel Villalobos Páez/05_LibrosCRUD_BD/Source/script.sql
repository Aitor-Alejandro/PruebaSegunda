CREATE DATABASE libreria;
USE libreria;

CREATE TABLE `libreria`.`libros` (
  `isbn` INT NOT NULL,
  `titulo` VARCHAR(200) NULL,
  `tematica` VARCHAR(200) NULL,
  PRIMARY KEY (`isbn`));