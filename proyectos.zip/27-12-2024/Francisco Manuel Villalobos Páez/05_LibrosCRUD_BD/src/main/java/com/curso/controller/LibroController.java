package com.curso.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Libro;
import com.curso.service.LibroService;
/**
 * @author Francisco Manuel Villalobos
 * @version 1.0 27/12/2024
 */
@RestController
public class LibroController {

	@Autowired
	private LibroService libroService;
	
	@GetMapping(value="/libros")
	public List<Libro> libros(){
		return libroService.findAll();
	}
	
	@GetMapping(value="/libros/{isbn}")
	public Libro buscarLibro(@PathVariable("isbn") int isbn) {
		return libroService.findById(isbn);
	}
	
	//TODO - Titulo y tematica
	
	@PostMapping(value="/libros")
	public void actualizarLibro(@RequestBody Libro l) {
		libroService.save(l);
	}
	
	@PutMapping(value="/libros")
	public void modificarLibro(@RequestBody Libro l) {
		libroService.update(l);
	}
	
	@DeleteMapping(value="/libros/{isbn}")
	public List<Libro> borrarLibro(@PathVariable("isbn") int isbn) {
		return libroService.delete(isbn);
	}
}
