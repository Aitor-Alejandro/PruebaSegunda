package com.curso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;
/**
 * @author Francisco Manuel Villalobos
 * @version 1.0 27712/2024
 */
@Service
public class LibroServiceImpl implements LibroService {
	
	@Autowired
	private LibroRepository libroRepository;

	@Override
	public List<Libro> findAll() {
		return libroRepository.findAll();
	}

	@Override
	public Libro findById(int isbn) {
		return libroRepository.findById(isbn).orElse(null);
	}
	
	/*@Override
	public Optional<Libro> findById(int isbn) {
		return libroRepository.findById(isbn);
	}*/

	@Override
	public void save(Libro l) {
		libroRepository.save(l);

	}

	@Override
	public void update(Libro l) {
		libroRepository.save(l);

	}

	@Override
	public List<Libro> delete(int isbn) {
		libroRepository.deleteById(isbn);
		return libroRepository.findAll();
	}

	/*@Override
	public List<Libro> findByTitulo(String titulo) {
		return libroRepository.buscarLibrosPorTitulo(titulo);
	}

	@Override
	public List<Libro> findByTematica(String tematica) {
		return libroRepository.findAllByTematicaIgnoreCase(tematica);
	}*/

}
