package com.curso.service;

import java.util.List;

import com.curso.model.Libro;

/**
 * @author Francisco Manuel Villalobos
 * @version 1.0 27/12/2024
 */
public interface LibroService {
	List<Libro> findAll();
	Libro findById(int isbn);
	void save(Libro l);
	void update(Libro l);
	List<Libro> delete(int isbn);
	//List<Libro> findByTitulo(String titulo);
	//List<Libro> findByTematica(String tematica);
}
