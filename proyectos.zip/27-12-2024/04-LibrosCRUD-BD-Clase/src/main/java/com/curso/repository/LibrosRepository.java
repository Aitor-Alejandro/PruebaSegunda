package com.curso.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.curso.model.Libro;

public interface LibrosRepository extends JpaRepository<Libro, Integer> {
//Ejercicio para vosotros
//usando @Query---->   permita buscar por titulo
//usando keyword--->   permita buscar por tematica
}
