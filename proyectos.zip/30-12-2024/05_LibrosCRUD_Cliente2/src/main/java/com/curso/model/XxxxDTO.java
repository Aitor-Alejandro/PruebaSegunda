package com.curso.model;

public class XxxxDTO {

}
