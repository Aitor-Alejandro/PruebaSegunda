package com.curso.service;

import java.util.List;

import com.curso.model.Ejemplar;

public interface EjemplaresService {
	List<Ejemplar> nuevoEjemplar(Ejemplar ejemplar);
}
